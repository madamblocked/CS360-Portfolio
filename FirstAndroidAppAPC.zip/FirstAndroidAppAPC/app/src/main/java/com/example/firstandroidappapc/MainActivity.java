 package com.example.firstandroidappapc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


 public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //  Check EditText and disable/enable the button accordingly.
        EditText editText = findViewById(R.id.nameText);
        Button button = findViewById(R.id.buttonSayHello);

        if (editText.getText().length() > 0) {

            button.setEnabled(true);

        }
        else {

            button.setEnabled(false);

        }

        //  Add a TextWatcher to the EditText control for button Enable/Disable
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                //  Leaving blank on purpose.

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                Button button = findViewById(R.id.buttonSayHello);

                if (charSequence.length() > 0) {

                    button.setEnabled(true);

                }
                else {

                    button.setEnabled(false);

                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

                //  Leaving blank on purpose.

            }
        });
    }
    public void SayHello(android.view.View Greeting){

        EditText editText = findViewById(R.id.nameText);
        TextView textView = findViewById(R.id.textGreeting);

        if (editText.getText().toString().length() > 0)
        {

            textView.setText(String.format(getString(R.string.app_greeting), editText.getText()));

        }
        else
        {

            textView.setText("You must enter a name");
        }
    }

}